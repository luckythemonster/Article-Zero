using System;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;

#if UNITY_EDITOR
using UnityEditor;
#endif

namespace EdTech
{
    public partial class EdWorld : MonoBehaviour
    {
        [HideInInspector][NonSerialized] public Dictionary<long, Tile> TileIds = new Dictionary<long, Tile>();

        public const string WhiteSpriteRef = "white__white__a12b9bcc-d219-4d05-b006-1606a8e11978";

        public float UnitScale = EdWorldExtensions.DefaultUnitScale;

        public string SpawnOnStart = "";
        public Action<EdWorld> PostStart;
        public Action<EdLevel> PostLevelSpawn;

        public EdLevel[] Levels;
        public SpriteMapItem[] OverrideSpriteMap;
        public SOSpriteMap[] SpriteMaps;
        public bool DontSpawnAnythingOnStart;

        public List<EdLevel> SpawnedLevels = new List<EdLevel>();
        
        [Header("Mesh Tile Settings")]
        [Tooltip("Default shader for mesh tiles. Required for builds. Use Sprites/Default or Unlit/Transparent.")]
        public Shader DefaultMeshShader;
        [HideInInspector] public bool UseMeshTiles = false;

        [HideInInspector] public Dictionary<string, Sprite> _spriteIdMap;
        [HideInInspector] public Dictionary<string, Sprite> _overrideSpriteIdMap;
        public Func<TilePrototype, GameObject> CustomSpawnTileFunc;
        public Action<Board> BoardSpawnedAction;

        public bool IsPaused { get; set; }

        private void Awake()
        {
            EdWorldExtensions.Awake(this);
        }

        public void Start()
        {
            EdWorldExtensions.Start(this);
            PostStart?.Invoke(this);
        }

        public void ReloadAllLevels()
        {
            List<EdLevel> sol = new List<EdLevel>();
            var allLevels = Resources.LoadAll<SOLevel>("");
            var allLevelsDic = allLevels.GroupBy(x => x.name).ToDictionary(x => x.Key, x => x.First());
            foreach (var name in EdWorldData.Instance.LevelNames)
            {
                var levelDef = allLevelsDic[name]?.LevelDef;
                sol.Add(levelDef);
            }
            Levels = sol.ToArray();
        }
    }

    public static class EdWorldExtensions
    {
        public const float DefaultUnitScale = 0.02f;

        public static void Awake(EdWorld world)
        {
            DateTime t = DateTime.Now;
            Debug.Log($"EdWorld.Awake at {t}");
            
            // Initialize UseMeshTiles from EdWorldData
            world.UseMeshTiles = EdWorldData.HasMeshTileData;
            
            //if (world._spriteIdMap == null) RebuildSpriteCacheFromSpriteMap(world);
            var elapsed = DateTime.Now - t;
            Debug.Log($"Sprite cache rebuilt in {elapsed.TotalMilliseconds}ms");
        }

        public static void Start(EdWorld world)
        {
            DateTime t = DateTime.Now;
            Debug.Log($"EdWorld.Start at {t}");
            //ResetSpriteCache(world);
            //RebuildSpriteCacheFromSpriteMap(world);
            var elapsed = DateTime.Now - t;
            Debug.Log($"Sprite cache rebuilt in {elapsed.TotalMilliseconds}ms");
            if (EdWorldData.Levels == null) world.ReloadAllLevels();
            else world.Levels = EdWorldData.Levels;
            if (string.IsNullOrWhiteSpace(world.SpawnOnStart))
            {
                if (world.Levels != null)
                {
                    foreach (var level in world.Levels)
                    {
                        if (level?.IsEntryPoint == true)
                        {
                            world.SpawnOnStart = level?.Name;
                            break;
                        }
                    }
                }
            }
            elapsed = DateTime.Now - t;
            Debug.Log($"Levels loaded in {elapsed.TotalMilliseconds}ms");
            if (!world.DontSpawnAnythingOnStart && !string.IsNullOrWhiteSpace(world.SpawnOnStart))
            {
                Debug.Log($"Spawning level {world.SpawnOnStart}");
                SpawnLevelById(world, world.SpawnOnStart);
            }
            elapsed = DateTime.Now - t;
            Debug.Log($"Level {world.SpawnOnStart} spawned in {elapsed.TotalMilliseconds}ms");
        }

        public static Sprite GetUnitySpriteById(this EdWorld world, string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return null;
            var runtimeSprite = EdPlayLoaderFactory.Instance.GetUnitySprite(id);
            if (runtimeSprite != null) return runtimeSprite;
            if (world._overrideSpriteIdMap == null) RebuildOverrideSpriteIdMap(world);
            if (world._overrideSpriteIdMap.TryGetValue(id, out var sprite))
                return sprite;
            if (world._spriteIdMap == null) return null;
            if (world._spriteIdMap.TryGetValue(id, out sprite))
                return sprite;

            Debug.LogWarning($"Sprite {id} not found in sprite map.");
            return null;
        }

        public static void RebuildOverrideSpriteIdMap(this EdWorld world)
        {
            var map = new Dictionary<string, Sprite>();
            if (world.OverrideSpriteMap == null) world.OverrideSpriteMap = new SpriteMapItem[0];
            foreach (var spriteMapItem in world.OverrideSpriteMap)
            {
                map[spriteMapItem.Id] = spriteMapItem.Sprite;
            }
            world._overrideSpriteIdMap = map;
        }

        public static void ResetSpriteCache(this EdWorld world)
        {
            world._spriteIdMap = null;
        }

        public static void RebuildSpriteCacheFromSpriteMaps(this EdWorld world, SOSpriteMap[] spriteMaps)
        {
            var t = DateTime.Now;
            world._spriteIdMap = new Dictionary<string, Sprite>();
            if (spriteMaps.Length == 0 || spriteMaps.All(x => x == null)) return;
            for (int i = 0; i < spriteMaps.Length; i++)
            {
                var sm = spriteMaps[i];
                if (sm == null) continue;
                if (sm.Items == null) continue;
                foreach (var spriteMapItem in sm.Items)
                {
                    world._spriteIdMap[spriteMapItem.Id] = spriteMapItem.Sprite;
                }
            }
            var elapsed = DateTime.Now - t;
            Debug.Log($"Sprite cache rebuilt from SpriteMap in {elapsed.TotalMilliseconds}ms");
        }

        public static void RebuildSpriteCache(this EdWorld world)
        {
            if (world.SpriteMaps.Length == 0 || world.SpriteMaps.All(x => x == null)) return;
            RebuildSpriteCacheFromSpriteMaps(world, world.SpriteMaps);
        }

        public static GameObject Spawn(this EdWorld world, Transform parent, EdTile tile, int z, EdBoard board, float levelHeight)
        {
            var prototype = new TilePrototype
            {
                Board = board,
                Tile = tile,
                LevelHeight = levelHeight,
                Z = z,
                Parent = parent,
            };

            if (world.CustomSpawnTileFunc != null)
                return world.CustomSpawnTileFunc(prototype);

            return world.DefaultTileSpawn(prototype);
        }

        public static GameObject DefaultTileSpawn(this EdWorld world, TilePrototype prototype)
        {
            return TileExtensions.Spawn(prototype, world);
        }


        public static Board Spawn(this EdWorld world, Transform parent, EdBoard board, int z, float levelHeight)
        {
            var instance = new GameObject(board.Name);
            instance.transform.SetParent(parent);
            instance.transform.localPosition = new Vector3(0, 0);
            var boardBehavior = instance.AddComponent<Board>();

            if (board.Walls != null)
            {
                var polygonCollider = instance.AddComponent<PolygonCollider2D>();
                polygonCollider.useDelaunayMesh = true;
                polygonCollider.pathCount = board.Walls.Length;
                for (int i = 0; i < board.Walls.Length; i++)
                {
                    Vector2[] points = new Vector2[board.Walls[i].Polygon.Length / 2];
                    for (int j = 0; j < points.Length; j++)
                    {
                        points[j] = new Vector2(
                            world.UnitScale * board.Walls[i].Polygon[j * 2],
                            world.UnitScale * (levelHeight - board.Walls[i].Polygon[j * 2 + 1]));
                    }
                    polygonCollider.SetPath(i, points);
                }
            }

            if (board.Tiles != null)
            {
                foreach (var tile in board.Tiles)
                {
                    var tileInstance = Spawn(world, instance.transform, tile, z, board, levelHeight);
                    if (tileInstance != null)
                        tileInstance.transform.SetParent(instance.transform);
                }
            }
            else
            {
                Debug.LogWarning($"Board {board.Name}/{board.Id} has no tiles.");
            }

            return boardBehavior;
        }

        public static GameObject Spawn(this EdWorld world, Transform parent, EdQuad quad, int z, float levelHeight)
        {
            var sprite = GetUnitySpriteById(world, quad.SpriteId);
            if (sprite == null) return null;

            var cropWidth = sprite.bounds.size.x * sprite.pixelsPerUnit;
            var cropHeight = sprite.bounds.size.y * sprite.pixelsPerUnit;
            float tileX = cropWidth;
            float tileY = cropHeight;

            var instance = new GameObject(quad.Name);
            instance.transform.SetParent(parent);
            instance.transform.localScale = new Vector3(quad.Width * world.UnitScale, quad.Height * world.UnitScale, 1);
            //var position = new Vector3(quad.X + quad.Width * 0.5f * UnitScale, levelHeight - quad.Height - quad.Y + quad.Height * 0.5f * UnitScale, 0);
            var position = new Vector3(quad.X + quad.Width * 0.5f, levelHeight - quad.Y - quad.Height * 0.5f, 0);
            //position.x += quad.Width * 0.5f;
            position *= world.UnitScale;
            instance.transform.localPosition = position;

            SpriteRenderer srBgRenderer = null;
            if (quad.Fill != default)
            {
                var srBg = new GameObject("SpriteRenderer Background");
                srBg.transform.SetParent(instance.transform);
                srBg.transform.localPosition = new Vector3(0, 0);
                srBgRenderer = srBg.AddComponent<SpriteRenderer>();
                srBgRenderer.sprite = GetUnitySpriteById(world, EdWorld.WhiteSpriteRef);
            }

            var srGo = new GameObject("SpriteRenderer");
            srGo.transform.SetParent(instance.transform);
            srGo.transform.localPosition = new Vector3(0, 0);
            var spriteRenderer = srGo.AddComponent<SpriteRenderer>();
            spriteRenderer.sprite = sprite;

            var collider = instance.AddComponent<BoxCollider2D>();
            Vector2 colliderSize = collider.size;
            if (quad.Tile == EdTileMode.Tile)
            {
                spriteRenderer.drawMode = SpriteDrawMode.Tiled;
                if (quad.TileX > 0)
                {
                    if (quad.TileRelativeCoords)
                        tileX = quad.Width / (float)quad.TileX;
                    else
                        tileX = (float)quad.TileX;
                }
                if (quad.TileY > 0)
                {
                    if (quad.TileRelativeCoords)
                        tileY = quad.Height / (float)quad.TileY;
                    else
                        tileY = (float)quad.TileY;
                }
                spriteRenderer.size = new Vector2(tileX, tileY);
                spriteRenderer.transform.localScale = new Vector3(1.0f / tileX, 1.0f / tileY, 1);
            }
            else
            {
                Vector2 spriteSize = spriteRenderer.sprite.bounds.size;
                Vector3 scale = Vector3.one;
                scale.x = colliderSize.x / spriteSize.x;
                scale.y = colliderSize.y / spriteSize.y;
                srGo.transform.localScale = scale;
            }

            if (srBgRenderer != null)
            {
                Vector2 spriteSize = srBgRenderer.sprite.bounds.size;
                Vector3 scale = Vector3.one;
                scale.x = colliderSize.x / spriteSize.x;
                scale.y = colliderSize.y / spriteSize.y;
                srBgRenderer.transform.localScale = scale;

                var bgColor = EdExtensions.GetColor(quad.Fill);
                bgColor.a *= quad.Opacity;
                srBgRenderer.color = bgColor;
                srBgRenderer.enabled = quad.IsVisible;
                srBgRenderer.sortingOrder = z * 2 + 1;
            }
            GameObject.DestroyImmediate(collider);

            spriteRenderer.sortingOrder = z * 2 + 1;
            var color = EdExtensions.GetColor(quad.Tint);
            color.a *= quad.Opacity;
            spriteRenderer.color = color;
            spriteRenderer.enabled = quad.IsVisible;
            return instance;
        }

        public static GameObject SpawnLevelPreviewStamps(this EdWorld world, EdLevel level)
        {
            if (level?.PreviewStamps == null) return default;
            if (level.PreviewStamps.Length == 0) return default;
            var instance = new GameObject($"Previews {level.Name}");
            instance.AddComponent<DieOnStart>();

            var z = 0;
            foreach (var stamp in level.PreviewStamps)
            {
                var stampQuad = ToQuad(stamp, null);
                var stampInstance = Spawn(world, instance.transform, stampQuad, z++, (float)level.Height);
                if (stampInstance != null)
                    stampInstance.transform.SetParent(instance.transform);
            }

            return instance;
        }

        public static GameObject Spawn(this EdWorld world, EdLevel level)
        {
            var t = DateTime.Now;
            if (level == null) return default;
            level = level.FlattenLevel();
            world.SpawnedLevels.Add(level);

            var spriteMapName = "DefaultSpriteMap";
            if (!string.IsNullOrWhiteSpace(level.SpriteMapName))
                spriteMapName = level.SpriteMapName;
            var levelSpriteMap = Resources.Load<SOSpriteMap>(spriteMapName);
            var spriteMaps = world.SpriteMaps.Union(new[] { levelSpriteMap }).ToArray();
            world.RebuildSpriteCacheFromSpriteMaps(spriteMaps);
            Resources.UnloadUnusedAssets();

            var instance = new GameObject(level.Name);
            instance.transform.SetParent(world.transform);
            //instance.transform.SetParent(transform);
            instance.transform.position = new Vector3(0, 0);
            int z = -1;
            foreach (var thing in level.Things)
            {
                z++;
                if (thing is EdBoard board)
                {
                    List<(Board behavior, EdBoard data, int z, BoardStamp stamp)> boardBehaviors =
                        new List<(Board behavior, EdBoard data, int z, BoardStamp stamp)>();
                    if (board.Stamps != null)
                    {
                        foreach (var stamp in board.Stamps)
                        {
                            var stampQuad = ToQuad(stamp, board);
                            var stampInstance = Spawn(world, instance.transform, stampQuad, z++, (float)level.Height);
                            if (stampInstance != null)
                            {
                                stampInstance.transform.SetParent(instance.transform);
                                boardBehaviors.Add((stampInstance.AddComponent<Board>(), board, z, stamp));
                                //boardBehavior.BoardSpawned(world, (float)level.Height, board, z, stamp);
                            }
                        }
                    }

                    // Use mesh tiles if enabled, otherwise use regular spawn
                    if (world.UseMeshTiles)
                    {
                        var boardBehavior = world.SpawnWithMesh(instance.transform, board, z, (float)level.Height, level.Name);
                        boardBehaviors.Add((boardBehavior, board, z, null));
                    }
                    else
                    {
                        var boardBehavior = world.Spawn(instance.transform, board, z, (float)level.Height);
                        boardBehaviors.Add((boardBehavior, board, z, null));
                    }
                    foreach (var s in boardBehaviors)
                    {
                        var boardBehavior = s.behavior;
                        var boardData = s.data;
                        var stamp = s.stamp;
                        DataComponentsDynamicLoader.LoadDataComponents(boardBehavior, boardData.Variables, boardData.DataComponents);
                        boardBehavior.BoardSpawned(world, (float)level.Height, boardData, s.z, stamp);
                        world.BoardSpawnedAction?.Invoke(boardBehavior);
                    }
                }
                else if (thing is EdQuad quad)
                {
                    var quadInstance = Spawn(world, instance.transform, quad, z, (float)level.Height);
                    if (quadInstance != null)
                        quadInstance.transform.SetParent(instance.transform);
                }
            }

            var levelBehavior = instance.AddComponent<Level>();
            DataComponentsDynamicLoader.LoadDataComponents(levelBehavior, level.Variables, level.DataComponents);
            levelBehavior.Spawned(world, level, (float)level.Height);
            
            world.BroadcastMessage("LevelSpawned", level, SendMessageOptions.DontRequireReceiver);
            instance.SendMessage("LevelSpawned", level, SendMessageOptions.DontRequireReceiver);

            var elapsed = DateTime.Now - t;
            Debug.Log($"Level {level.Name} spawned in {elapsed.TotalMilliseconds}ms");
            world.PostLevelSpawn?.Invoke(level);
            return instance;
        }

        public static GameObject SpawnLevelById(this EdWorld world, string id)
        {
            var level = world.Levels.FirstOrDefault(x => x?.Id == id) ??
                world.Levels.FirstOrDefault(x => x?.Name == id);

            if (EdPlayLoaderFactory.Instance.Levels.TryGetValue(id, out var dynLevel))
            { }
            level = dynLevel ?? level;

            if (level == null) return default;
            return Spawn(world, level);
        }

        public static EdQuad ToQuad(BoardStamp stamp, EdBoard board)
        {
            var ifill = board?.BackgroundColor ?? default;
            if (ifill != default)
            {
                var color = EdExtensions.GetColor(ifill);
                color.a *= board?.Opacity ?? 1;
                ifill = EdExtensions.GetUintColor(color);
            }

            return new EdQuad
            {
                SpriteId = stamp.SpriteId,
                X = stamp.X,
                Y = stamp.Y,
                Width = stamp.W,
                Height = stamp.H,
                Id = stamp.SpriteId,
                Name = stamp.SpriteId,
                Opacity = 1,
                Tint = EdTileDef.DefaultTintColor,
                BitmapBlendingModeId = default,
                Tile = EdTileMode.Stretch,
                Fill = ifill,
                ParallaxX = board?.ParallaxX ?? 1,
                ParallaxY = board?.ParallaxY ?? 1,
                IsVisible = board?.IsVisible ?? true,
            };
        }

        public static EdTileDef GetTileDef(this EdWorldData d, uint handle)
        {
            if (handle == 0) return null;
            var dyn = EdPlayLoaderFactory.Instance.GetTileDefByHandle(handle);
            if (d.TileDefHandles.TryGetValue(handle, out var tileDef))
            {
            }
            return dyn ?? tileDef;
        }

        public static EdTileDef GetTileDef(this EdWorldData d, string id)
        {
            if (id == null) return null;
            var dyn = EdPlayLoaderFactory.Instance.GetTileDef(id);
            if (d.TileDefs.TryGetValue(id, out var tileDef))
            {
            }
            return dyn ?? tileDef;
        }
    }
}
