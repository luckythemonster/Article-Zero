using UnityEngine;
using UnityEngine.UI;
using System.IO;
using EdTech;
using System.Collections.Generic;
using System.Collections;
using System;

public class EdPlayLoader : MonoBehaviour
{
    public static string Level;
    
    public TMPro.TMP_InputField TxtPath, TxtLevel;
    public Button BtnLoad;
    public Toggle TglLoadSprites;

    public void Start()
    {
        TxtPath.text = PlayerPrefs.GetString("EdPlayPath", "");
        TxtLevel.text = PlayerPrefs.GetString("EdPlayLevel", "");
        TglLoadSprites.isOn = PlayerPrefs.GetInt("EdPlayLoadSprites", 1) == 1;
        BtnLoad.onClick.AddListener(() =>
        {
            var path = TxtPath.text;
            if (string.IsNullOrEmpty(path))
            {
                Debug.LogError("Path is empty");
                return;
            }
            
            PlayerPrefs.SetString("EdPlayPath", path);
            PlayerPrefs.SetString("EdPlayLevel", TxtLevel.text);
            PlayerPrefs.SetInt("EdPlayLoadSprites", TglLoadSprites.isOn ? 1 : 0);
            PlayerPrefs.Save();
            var factory = new EdPlayLoaderFactory(path);
            Level = TxtLevel.text;
            factory.LoadSprites = TglLoadSprites.isOn;
            factory.LoadLoadingScene();
        });
    }
}

public class EdPlayLoaderFactory
{
    public string WorkingDirectory;
    public string JsonPath;
    public bool LoadSprites = true;
    EdDynamicWorld Data;
    public Dictionary<string, EdSprite> EdSprites = new Dictionary<string, EdSprite>();
    public Dictionary<string, Sprite> UnitySprites = new Dictionary<string, Sprite>();
    public Dictionary<string, EdTileDef> TileDefs = new Dictionary<string, EdTileDef>();
    public Dictionary<uint, EdTileDef> TileDefsByHandle = new Dictionary<uint, EdTileDef>();
    public Dictionary<string, EdLevel> Levels = new Dictionary<string, EdLevel>();
    public Dictionary<string, MeshTileData> MeshTileData = new Dictionary<string, MeshTileData>();

    public static EdPlayLoaderFactory Instance { get; private set; } = new EdPlayLoaderFactory();

    public EdPlayLoaderFactory()
    {
    }

    public EdPlayLoaderFactory(string path)
    {
        WorkingDirectory = path;
        Instance = this;
        JsonPath = Path.Combine(path, "edplay.json");
    }

    public IEnumerator LoadCo(Action<string> message)
    {
        if (!Directory.Exists(WorkingDirectory))
        {
            Debug.LogError("Directory not found: " + WorkingDirectory);
            message($"Directory not found: {WorkingDirectory}");
            yield break;
        }
        if (!File.Exists(JsonPath))
        {
            Debug.LogError("File not found: " + JsonPath);
            message($"File not found: {JsonPath}");
            yield break;
        }
        message($"Loading World...\n{JsonPath}");
        yield return new WaitForFixedUpdate();
        LoadJson();
        yield return new WaitForFixedUpdate();
        if (LoadSprites)
        {
            message("Loading Sprites...");
            yield return LoadSpriteSheets(message);
        }
        message("Loading Tile Definitions...");
        yield return new WaitForFixedUpdate();
        LoadTileDefs();
        message("Loading Levels...");
        yield return new WaitForFixedUpdate();
        LoadLevels();
        message("Loading Scene...");
        yield return new WaitForFixedUpdate();
        LoadScene();
    }

    public void LoadJson()
    {
        if (!File.Exists(JsonPath))
        {
            Debug.LogError("File not found: " + JsonPath);
            return;
        }
        var json = File.ReadAllText(JsonPath);
        Data = (EdDynamicWorld)JsonUtility.FromJson(json, typeof(EdDynamicWorld));
    }

    public IEnumerator LoadSpriteSheets(Action<string> message)
    {
        foreach (var sheet in Data.SpriteSheets)
        {
            yield return LoadSpriteSheet(sheet, message);
            yield return new WaitForFixedUpdate();
        }
    }

    public IEnumerator LoadSpriteSheet(EdSpriteSheet sheet, Action<string> message)
    {
        var path = Path.Combine(WorkingDirectory, Path.GetFileName(sheet.RelativePath));
        message($"Loading Sprite Sheet...\n{Path.GetFileName(path)}\nReading File");
        yield return new WaitForFixedUpdate();
        if (!File.Exists(path))
        {
            Debug.LogError("File not found: " + path);
            message($"File not found: {path}");
            yield break;
        }
        var bytes = File.ReadAllBytes(path);
        message($"Loading Sprite Sheet...\n{Path.GetFileName(path)}\nCreating Texture");
        yield return new WaitForFixedUpdate();
        var texture = new Texture2D(sheet.Width, sheet.Height, TextureFormat.RGBA32, false, false);
        texture.filterMode = FilterMode.Point;
        if (!texture.LoadImage(bytes))
        {
            Debug.LogError("Failed to load image: " + path);
            message($"Failed to load image: {path}");
            yield break;
        }
        message($"Loading Sprite Sheet...\n{Path.GetFileName(path)}\nCreating Sprites");
        yield return new WaitForFixedUpdate();
        foreach (var edSprite in sheet.Sprites)
        {
            edSprite.Y = texture.height - edSprite.Y - edSprite.Height;
            var rect = new Rect(edSprite.X, edSprite.Y, edSprite.Width, edSprite.Height);
            var pivot = new Vector2(0.5f, 0.5f);
            var sprite = Sprite.Create(texture, rect, pivot, 16, 0, 
                SpriteMeshType.FullRect, Vector4.zero, false);
            if (!string.IsNullOrWhiteSpace(edSprite.Ref))
            {
                UnitySprites[edSprite.Ref] = sprite;
                EdSprites[edSprite.Ref] = edSprite;
            }
            UnitySprites[edSprite.Id] = sprite;
            EdSprites[edSprite.Id] = edSprite;
            edSprite.UnityName = sprite.name;
        }
    }

    public void LoadTileDefs()
    {
        foreach (var tileDef in Data.TileDefs)
        {
            TileDefs[tileDef.Id] = tileDef;
            if (!string.IsNullOrWhiteSpace(tileDef.Ref))
                TileDefs[tileDef.Ref] = tileDef;
            TileDefsByHandle[tileDef.Handle] = tileDef;
        }
    }

    public void LoadLevels()
    {
        if (Data.MeshTileData != null && Data.MeshTileData.Length > 0)
        {
            MeshTileData.Clear();
            foreach (var meshTileData in Data.MeshTileData)
            {
                MeshTileData[meshTileData.Name] = meshTileData; 
            }
        }
        if (Data.Levels != null && Data.Levels.Length > 0)
        {
            Levels.Clear();
            foreach (var level in Data.Levels)
            {
                level.FlattenLevel();
                Levels[level.Id] = level;
                Levels[level.Name] = level;
            }
        }
    }

    public void LoadLoadingScene()
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene("PlayLoadingScene");
    }

    public void LoadScene()
    {
        var edWorldData = new EdWorldData();
        UnityEngine.SceneManagement.SceneManager.LoadSceneAsync(Bootloader.GameSceneName);
    }

    public Sprite GetUnitySprite(string id)
    {
        if (id == null) return null;
        if (UnitySprites.TryGetValue(id, out var sprite))
        {
            return sprite;
        }
        return null;
    }

    public EdSprite GetEdSprite(string id)
    {
        if (id == null) return null;
        if (EdSprites.TryGetValue(id, out var sprite))
        {
            return sprite;
        }
        return null;
    }

    public EdTileDef GetTileDef(string id)
    {
        if (id == null) return null;
        if (TileDefs.TryGetValue(id, out var tileDef))
        {
            return tileDef;
        }
        return null;
    }

    public EdTileDef GetTileDefByHandle(uint handle)
    {
        if (handle == 0) return null;
        if (TileDefsByHandle.TryGetValue(handle, out var tileDef))
        {
            return tileDef;
        }
        return null;
    }
}
