using System;
using System.Collections.Generic;
using System.Text;

using UnityEngine;

namespace EdTech
{
    public partial class Level : MonoBehaviour
    {
        EdWorld world;
        EdLevel level;
        float levelHeight;

        public void Spawned(EdWorld world, EdLevel level, float levelHeight)
        {
            this.world = world;
            this.level = level;
            this.levelHeight = levelHeight;
        }
    }
}
