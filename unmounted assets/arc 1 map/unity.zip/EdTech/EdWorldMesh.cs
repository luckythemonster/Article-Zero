using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

namespace EdTech
{
    public partial class EdWorld : MonoBehaviour
    {
        // Add mesh tile support
        private Dictionary<string, MeshTileData> _meshTileDataCache = new Dictionary<string, MeshTileData>();
        public string MeshDataPath = "Meshes";
        
        public MeshTileData GetMeshTileData(string boardId)
        {
            if (boardId == null) return null;

            if (_meshTileDataCache.TryGetValue(boardId, out var cached))
                return cached;
                
            if (EdPlayLoaderFactory.Instance.MeshTileData != null && 
                EdPlayLoaderFactory.Instance.MeshTileData.TryGetValue(boardId, out cached))
                return cached;

            // Try from Resources first using boardId
            var resourcePath = $"Meshes/{boardId}";
            var textAsset = Resources.Load<TextAsset>(resourcePath);
            if (textAsset != null)
            {
                try
                {
                    var meshData = JsonUtility.FromJson<MeshTileData>(textAsset.text);
                    _meshTileDataCache[boardId] = meshData;
                    return meshData;
                }
                catch (System.Exception e)
                {
                    Debug.LogError($"Failed to deserialize mesh data for {boardId}: {e.Message}");
                }
            }
            
            // Try to load mesh data from streaming assets
            var streamingPath = Path.Combine(Application.streamingAssetsPath, MeshDataPath, $"{boardId}.json");
            if (File.Exists(streamingPath))
            {
                try
                {
                    var json = File.ReadAllText(streamingPath);
                    var meshData = JsonUtility.FromJson<MeshTileData>(json);
                    _meshTileDataCache[boardId] = meshData;
                    return meshData;
                }
                catch (System.Exception e)
                {
                    Debug.LogError($"Failed to load mesh data from {streamingPath}: {e.Message}");
                }
            }
            
            return null;
        }
        
        public MeshTileData GetMeshTileDataByName(string boardName)
        {
            if (boardName == null) return null;

            if (_meshTileDataCache.TryGetValue(boardName, out var cached))
                return cached;

            if (EdPlayLoaderFactory.Instance.MeshTileData != null &&
                EdPlayLoaderFactory.Instance.MeshTileData.TryGetValue(boardName, out cached))
                return cached;

            // Try from Resources first using board name
            var resourcePath = $"Meshes/{boardName}";
            var textAsset = Resources.Load<TextAsset>(resourcePath);
            if (textAsset != null)
            {
                try
                {
                    var meshData = JsonUtility.FromJson<MeshTileData>(textAsset.text);
                    _meshTileDataCache[boardName] = meshData;
                    return meshData;
                }
                catch (System.Exception e)
                {
                    Debug.LogError($"Failed to deserialize mesh data for {boardName}: {e.Message}");
                }
            }
            
            return null;
        }
    }
    
    public static class EdWorldMeshExtensions
    {
        /// <summary>
        /// Comprehensive filename normalization that handles ALL illegal filename characters.
        /// This MUST match the Tyler export NormalizeFilename() function exactly.
        /// </summary>
        private static string NormalizeFilename(string name)
        {
            if (string.IsNullOrEmpty(name))
                return "unnamed";
                
            var normalizedName = name.Trim();
            
            // Replace ALL invalid filename characters with underscores
            // Note: We can't use Path.GetInvalidFileNameChars() in Unity, so we hardcode the common ones
            char[] invalidChars = { '\\', '/', ':', '*', '?', '"', '<', '>', '|' };
            foreach (var invalidChar in invalidChars)
            {
                normalizedName = normalizedName.Replace(invalidChar, '_');
            }
            
            // Replace control characters (ASCII 0-31)
            for (int i = 0; i < 32; i++)
            {
                normalizedName = normalizedName.Replace((char)i, '_');
            }
            
            // Also replace spaces with underscores for consistency
            normalizedName = normalizedName.Replace(' ', '_');
            
            // Replace any other problematic characters that might cause issues
            normalizedName = normalizedName.Replace('.', '_'); // Avoid confusion with file extensions
            normalizedName = normalizedName.Replace(',', '_'); // Commas can cause parsing issues
            normalizedName = normalizedName.Replace(';', '_'); // Semicolons can cause parsing issues
            normalizedName = normalizedName.Replace('(', '_'); // Parentheses can cause shell issues
            normalizedName = normalizedName.Replace(')', '_');
            normalizedName = normalizedName.Replace('[', '_'); // Brackets can cause shell issues  
            normalizedName = normalizedName.Replace(']', '_');
            normalizedName = normalizedName.Replace('{', '_'); // Braces can cause shell issues
            normalizedName = normalizedName.Replace('}', '_');
            normalizedName = normalizedName.Replace('&', '_'); // Ampersand can cause shell issues
            normalizedName = normalizedName.Replace('%', '_'); // Percent can cause shell issues
            normalizedName = normalizedName.Replace('$', '_'); // Dollar can cause shell issues
            normalizedName = normalizedName.Replace('#', '_'); // Hash can cause shell issues
            normalizedName = normalizedName.Replace('@', '_'); // At symbol can cause issues
            normalizedName = normalizedName.Replace('!', '_'); // Exclamation can cause shell issues
            normalizedName = normalizedName.Replace('~', '_'); // Tilde can cause issues
            normalizedName = normalizedName.Replace('`', '_'); // Backtick can cause shell issues
            normalizedName = normalizedName.Replace('^', '_'); // Caret can cause issues
            normalizedName = normalizedName.Replace('+', '_'); // Plus can cause issues in some contexts
            normalizedName = normalizedName.Replace('=', '_'); // Equals can cause issues
            
            // Remove consecutive underscores
            while (normalizedName.Contains("__"))
            {
                normalizedName = normalizedName.Replace("__", "_");
            }
            
            // Trim underscores from start and end
            normalizedName = normalizedName.Trim('_');
            
            // Ensure we have a valid filename
            if (string.IsNullOrEmpty(normalizedName))
                return "unnamed";
                
            // Ensure filename isn't too long (most filesystems have 255 char limit)
            if (normalizedName.Length > 200) // Leave room for .json extension
                normalizedName = normalizedName.Substring(0, 200).TrimEnd('_');
            
            return normalizedName;
        }
        
        private static string NormalizeMeshFileName(string levelName, string boardName)
        {
            if (string.IsNullOrEmpty(levelName) || string.IsNullOrEmpty(boardName))
                return "unnamed";
            
            var combined = $"{levelName}_{boardName}";
            return NormalizeFilename(combined);
        }
        
        // Extension method that replaces the regular Spawn when mesh tiles are available
        // This method signature matches what's needed in the level spawning code
        public static Board SpawnWithMesh(this EdWorld world, Transform parent, EdBoard board, int z, float levelHeight, string levelName = null)
        {
            var instance = new GameObject(board.Name);
            instance.transform.SetParent(parent);
            instance.transform.localPosition = new Vector3(0, 0);
            var boardBehavior = instance.AddComponent<Board>();
            
            // Check if we have mesh data for this board
            MeshTileData meshData = null;
            
            if (!string.IsNullOrEmpty(levelName))
            {
                // Use the same normalization logic as Tyler's export
                var meshFileName = NormalizeMeshFileName(levelName, board.Name);
                meshData = world.GetMeshTileDataByName(meshFileName);
            }
            
            if (meshData == null && !string.IsNullOrEmpty(levelName))
            {
                // Fallback: try the old simple normalization (for backwards compatibility)
                var oldMeshFileName = $"{levelName}_{board.Name.Replace(" ", "_")}";
                Debug.Log($"Fallback: Looking for mesh file with old naming: {oldMeshFileName}");
                meshData = world.GetMeshTileDataByName(oldMeshFileName);
            }
            
            if (meshData == null)
            {
                // Fallback to board ID
                meshData = world.GetMeshTileData(board.Id);
            }
            
            if (meshData == null)
            {
                // Final fallback to direct board name
                meshData = world.GetMeshTileDataByName(board.Name);
            }
            // First, collect all mesh chunks for this board
            var meshChunks = new List<MeshTileData>();

            if (meshData != null)
            {
                meshChunks.Add(meshData);
            }

            // Look for additional chunks with the pattern boardName_chunk_X_Y
            if (!string.IsNullOrEmpty(levelName))
            {
                // Check for chunked meshes
                var baseFileName = NormalizeMeshFileName(levelName, board.Name);

                // Try to find chunked versions
                for (int cx = 0; cx < board.ChunkWidth; cx++)
                {
                    for (int cy = 0; cy < board.ChunkHeight; cy++)
                    {
                        var chunkFileName = $"{baseFileName}_chunk_{cx}_{cy}";
                        var chunkData = world.GetMeshTileDataByName(chunkFileName);

                        if (chunkData != null && !meshChunks.Contains(chunkData))
                        {
                            meshChunks.Add(chunkData);
                        }
                    }
                }
            }

            if (meshChunks.Count > 0)
            {
                // Spawn all mesh chunks
                foreach (var chunk in meshChunks)
                {
                    var meshTileGO = MeshTileExtensions.SpawnMeshTile(
                        instance.transform,
                        chunk,
                        board,
                        levelHeight,
                        world,
                        z);
                }
                    
                // Still spawn interactive tiles that weren't included in the mesh
                if (board.Tiles != null)
                {
                    foreach (var tile in board.Tiles)
                    {
                        var tileInstance = world.Spawn(instance.transform, tile, z, board, levelHeight);
                        if (tileInstance != null)
                            tileInstance.transform.SetParent(instance.transform);
                    }
                }
            }
            else
            {
                Debug.Log($"No mesh data found for board {board.Name}, using traditional tiles");
                
                // Fall back to traditional tile spawning
                if (board.Tiles != null)
                {
                    foreach (var tile in board.Tiles)
                    {
                        var tileInstance = world.Spawn(instance.transform, tile, z, board, levelHeight);
                        if (tileInstance != null)
                            tileInstance.transform.SetParent(instance.transform);
                    }
                }
            }
            
            // Add walls/collision
            if (board.Walls != null)
            {
                var polygonCollider = instance.AddComponent<PolygonCollider2D>();
                polygonCollider.useDelaunayMesh = true;
                polygonCollider.pathCount = board.Walls.Length;
                for (int i = 0; i < board.Walls.Length; i++)
                {
                    Vector2[] points = new Vector2[board.Walls[i].Polygon.Length / 2];
                    for (int j = 0; j < points.Length; j++)
                    {
                        points[j] = new Vector2(
                            world.UnitScale * board.Walls[i].Polygon[j * 2], 
                            world.UnitScale * (levelHeight - board.Walls[i].Polygon[j * 2 + 1]));
                    }
                    //var points = board.Walls[i].Polygon.Select(p => new Vector2(
                    //    p.X * world.UnitScale,
                    //    (levelHeight - p.Y) * world.UnitScale
                    //    )).ToArray();
                    polygonCollider.SetPath(i, points);
                }
            }
            
            return boardBehavior;
        }
    }
}
