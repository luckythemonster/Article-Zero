using System;
using System.Collections.Generic;
using System.Linq;
using Unity.Burst;
using Unity.Collections;
using Unity.Jobs;
using Unity.Mathematics;
using UnityEngine;

namespace EdTech
{
    [Serializable]
    public class MeshTileData
    {
        public string Name;
        
        // Vertex data
        public float[] Vertices; // x,y,z per vertex
        public float[] UVs; // u,v per vertex
        public uint[] Colors; // Color per vertex (RGBA packed)
        
        // Triangle indices
        public int[] Triangles;
        
        // Submeshes for different materials/textures
        public MeshSubmesh[] Submeshes;
        
        // Metadata
        public float Width;
        public float Height;
        public float GeneratedWithLevelHeight;

        // Chunk information (for large boards split into multiple meshes)
        public int ChunkX = -1; // -1 means not chunked
        public int ChunkY = -1; // -1 means not chunked
        public int ChunkSize = 0; // Size in tiles

        // Tile mappings for individual sprite tiles within the mesh
        public TileMeshMapping[] TileMappings;
    }
    
    [Serializable]
    public class MeshSubmesh
    {
        public int StartIndex;
        public int IndexCount;
        public string SpriteId;
        public string TextureRef;
    }
    
    [Serializable]
    public class TileMeshMapping
    {
        public long TileId;
        public int X;
        public int Y;
        public int VertexStart;
        public int VertexCount;
        public int TriangleStart;
        public int TriangleCount;
    }

    // Burst-compiled job for parallel vertex inflation
    [BurstCompile]
    public struct InflateVerticesJob : IJobParallelFor
    {
        [ReadOnly] public NativeArray<float> sourceVertices;
        [ReadOnly] public NativeArray<int> vertexToTileIndex;
        [ReadOnly] public NativeArray<float2> tileCenters;
        [ReadOnly] public float inflationAmount;
        [ReadOnly] public float zOffsetScale;
        
        [WriteOnly] public NativeArray<float3> outputVertices;
        
        public void Execute(int i)
        {
            float x = sourceVertices[i * 3];
            float y = sourceVertices[i * 3 + 1];
            float z = sourceVertices[i * 3 + 2];
            
            int tileIndex = vertexToTileIndex[i];
            if (tileIndex >= 0)
            {
                float2 center = tileCenters[tileIndex];
                float dx = x - center.x;
                float dy = y - center.y;
                float distSq = dx * dx + dy * dy;
                
                if (distSq > 0.00000001f) // Avoid division by zero (squared threshold)
                {
                    // Use fast inverse square root for better performance
                    float invDist = math.rsqrt(distSq);
                    x += dx * invDist * inflationAmount;
                    y += dy * invDist * inflationAmount;
                }
                
                // Add small Z-offset based on tile position to prevent z-fighting
                // Use a hash of tile center position for consistent but varied offsets
                float zOffset = (math.abs(center.x * 73.1f + center.y * 97.3f) % 1.0f) * zOffsetScale;
                z -= zOffset; // Negative to push slightly away from camera
            }
            
            outputVertices[i] = new float3(x, y, z);
        }
    }
    
    public class MeshTile : MonoBehaviour
    {
        public MeshTileData Data;
        public EdWorld World;
        private MeshFilter meshFilter;
        private MeshRenderer meshRenderer;
        private Mesh mesh;
        
        // Threshold for using parallel processing
        private const int ParallelVertexThreshold = 500;
        
        public void Initialize(MeshTileData data, EdWorld world, float levelHeight = 0f)
        {
            Data = data;
            World = world;
            
            // Create mesh components
            meshFilter = gameObject.AddOrGetComponent<MeshFilter>();
            meshRenderer = gameObject.AddOrGetComponent<MeshRenderer>();
            
            // Build Unity mesh from data
            BuildMesh(levelHeight);
        }
        
        private void BuildMesh(float levelHeight = 0f)
        {
            if (mesh != null)
                DestroyImmediate(mesh);
                
            mesh = new Mesh();
            mesh.name = Data.Name;
            
            int vertexCount = Data.Vertices.Length / 3;
            var vertices = new Vector3[vertexCount];
            var uvs = new Vector2[vertexCount];
            var colors = new Color32[vertexCount];

            const float inflationAmount = 0.004f; // Small inflation to close gaps without overlap
            const float zOffsetScale = 0.0001f; // Very small Z-offset to prevent z-fighting

            if (Data.TileMappings != null && Data.TileMappings.Length > 0)
            {
                var vertexToTileIndex = new NativeArray<int>(vertexCount, Allocator.TempJob);
                var tileCenters = new NativeArray<float2>(Data.TileMappings.Length, Allocator.TempJob);

                for (int i = 0; i < vertexCount; i++) vertexToTileIndex[i] = -1;
                for (int t = 0; t < Data.TileMappings.Length; t++)
                {
                    var mapping = Data.TileMappings[t];
                    float2 center = float2.zero;
                    for (int v = mapping.VertexStart; v < mapping.VertexStart + mapping.VertexCount; v++)
                    {
                        vertexToTileIndex[v] = t;
                        center += new float2(Data.Vertices[v * 3], Data.Vertices[v * 3 + 1]);
                    }
                    tileCenters[t] = center / mapping.VertexCount;
                }

                var sourceVerts = new NativeArray<float>(Data.Vertices, Allocator.TempJob);
                var outputVerts = new NativeArray<float3>(vertexCount, Allocator.TempJob);

                var job = new InflateVerticesJob
                {
                    sourceVertices = sourceVerts,
                    vertexToTileIndex = vertexToTileIndex,
                    tileCenters = tileCenters,
                    inflationAmount = inflationAmount,
                    zOffsetScale = zOffsetScale,
                    outputVertices = outputVerts
                };

                int batchSize = Mathf.Max(32, vertexCount / (SystemInfo.processorCount * 4));
                JobHandle handle = job.Schedule(vertexCount, batchSize);
                handle.Complete();

                for (int i = 0; i < vertexCount; i++)
                {
                    var v = outputVerts[i];
                    vertices[i] = new Vector3(v.x, v.y, v.z);
                }

                sourceVerts.Dispose();
                outputVerts.Dispose();
                vertexToTileIndex.Dispose();
                tileCenters.Dispose();
            }
            else
            {
                // Simple inflation for meshes without tile mappings
                // Assume each 4 vertices form a quad and inflate from quad center
                for (int i = 0; i < vertexCount; i++)
                {
                    float x = Data.Vertices[i * 3];
                    float y = Data.Vertices[i * 3 + 1];
                    float z = Data.Vertices[i * 3 + 2];
                    
                    // For simple quad-based meshes, calculate local center for each quad
                    if (vertexCount >= 4)
                    {
                        int quadIndex = i / 4;
                        int vertInQuad = i % 4;
                        int quadStart = quadIndex * 4;
                        
                        if (quadStart + 3 < vertexCount)
                        {
                            // Calculate quad center
                            float centerX = 0, centerY = 0;
                            for (int q = 0; q < 4; q++)
                            {
                                int idx = quadStart + q;
                                centerX += Data.Vertices[idx * 3];
                                centerY += Data.Vertices[idx * 3 + 1];
                            }
                            centerX /= 4f;
                            centerY /= 4f;
                            
                            // Inflate vertex away from center
                            float dx = x - centerX;
                            float dy = y - centerY;
                            float dist = Mathf.Sqrt(dx * dx + dy * dy);
                            
                            if (dist > 0.0001f)
                            {
                                x += (dx / dist) * inflationAmount;
                                y += (dy / dist) * inflationAmount;
                            }
                            
                            // Add small Z-offset to prevent z-fighting
                            float zOffset = (Mathf.Abs(centerX * 73.1f + centerY * 97.3f) % 1.0f) * zOffsetScale;
                            z -= zOffset;
                        }
                    }
                    
                    vertices[i] = new Vector3(x, y, z);
                }
            }
            
            for (int i = 0; i < vertexCount; i++)
            {
                if (Data.UVs != null && i * 2 + 1 < Data.UVs.Length)
                    uvs[i] = new Vector2(Data.UVs[i * 2], Data.UVs[i * 2 + 1]);
                else
                    uvs[i] = Vector2.zero;

                if (Data.Colors != null && i < Data.Colors.Length)
                {
                    uint packedColor = Data.Colors[i];
                    colors[i] = new Color32((byte)((packedColor >> 24) & 0xFF), (byte)((packedColor >> 16) & 0xFF), (byte)((packedColor >> 8) & 0xFF), (byte)(packedColor & 0xFF));
                }
                else
                {
                    colors[i] = Color.white;
                }
            }
            
            mesh.vertices = vertices;
            mesh.uv = uvs;
            mesh.colors32 = colors;
            
            if (Data.Submeshes != null && Data.Submeshes.Length > 0)
            {
                mesh.subMeshCount = Data.Submeshes.Length;
                for (int i = 0; i < Data.Submeshes.Length; i++)
                {
                    var submesh = Data.Submeshes[i];
                    int[] triangles = new int[submesh.IndexCount];
                    Array.Copy(Data.Triangles, submesh.StartIndex, triangles, 0, submesh.IndexCount);
                    mesh.SetTriangles(triangles, i);
                }
            }
            else
            {
                mesh.triangles = Data.Triangles;
            }
            
            mesh.RecalculateBounds();
            mesh.RecalculateNormals();
            
            meshFilter.mesh = mesh;
            
            SetupMaterials();
        }
        
        private void SetupMaterials()
        {
            // Get shader from EdWorld (must be assigned for builds to work)
            Shader shader = World != null ? World.DefaultMeshShader : null;
            
            if (shader == null)
            {
                // Fallback for editor only - will likely fail in builds
                Debug.LogWarning("DefaultMeshShader not assigned in EdWorld! Trying Shader.Find (may fail in builds).");
                shader = Shader.Find("Sprites/Default");
                if (shader == null)
                    shader = Shader.Find("Unlit/Transparent");
            }
            
            if (shader == null)
            {
                Debug.LogError("No shader available for MeshTile! Please assign DefaultMeshShader in EdWorld.");
                return; // Can't create materials without a shader
            }

            if (Data.Submeshes != null && Data.Submeshes.Length > 0)
            {
                Material[] materials = new Material[Data.Submeshes.Length];

                for (int i = 0; i < Data.Submeshes.Length; i++)
                {
                    var submesh = Data.Submeshes[i];
                    var sprite = World.GetUnitySpriteById(submesh.SpriteId);
                    
                    Material mat = new Material(shader);
                    if (sprite != null)
                    {
                        mat.mainTexture = sprite.texture;
                    }
                    
                    materials[i] = mat;
                }
                
                meshRenderer.materials = materials;
                
                // Transform mesh UVs to handle sprite atlas cropping
                TransformMeshUVsForAtlas();
            }
            else
            {
                Material mat = new Material(shader);
                meshRenderer.material = mat;
            }
        }

        private void TransformMeshUVsForAtlas()
        {
            if (Data.Submeshes == null || Data.Submeshes.Length == 0) return;
            
            var uvs = mesh.uv;
            var uvsCopy = new Vector2[uvs.Length];
            Array.Copy(uvs, uvsCopy, uvs.Length);
            
            for (int submeshIndex = 0; submeshIndex < Data.Submeshes.Length; submeshIndex++)
            {
                var submesh = Data.Submeshes[submeshIndex];
                var sprite = World.GetUnitySpriteById(submesh.SpriteId);
                
                if (sprite == null) continue;
                
                // Get the sprite's UV rect within the texture atlas
                var spriteRect = sprite.textureRect;
                var textureSize = new Vector2(sprite.texture.width, sprite.texture.height);
                
                var uvRect = new Rect(
                    spriteRect.x / textureSize.x,
                    spriteRect.y / textureSize.y,
                    spriteRect.width / textureSize.x,
                    spriteRect.height / textureSize.y
                );
                
                // Get all unique vertex indices used by this submesh
                var vertexIndices = new HashSet<int>();
                var triangleStart = submesh.StartIndex;
                var triangleEnd = submesh.StartIndex + submesh.IndexCount;
                
                for (int i = triangleStart; i < triangleEnd && i < Data.Triangles.Length; i++)
                {
                    vertexIndices.Add(Data.Triangles[i]);
                }
                
                // Transform UVs for these vertices
                foreach (var vertexIndex in vertexIndices)
                {
                    if (vertexIndex < uvsCopy.Length)
                    {
                        var originalUV = uvsCopy[vertexIndex];
                        // Transform from sprite-local UV (0-1) to atlas UV rect
                        uvsCopy[vertexIndex] = new Vector2(
                            uvRect.x + originalUV.x * uvRect.width,
                            uvRect.y + originalUV.y * uvRect.height
                        );
                    }
                }
            }
            
            mesh.uv = uvsCopy;
        }
        
        private void OnDestroy()
        {
            if (mesh != null)
                DestroyImmediate(mesh);
        }
    }
    
    public static class MeshTileExtensions
    {
        public static GameObject SpawnMeshTile(
            Transform parent,
            MeshTileData meshData,
            EdBoard board,
            float levelHeight,
            EdWorld world,
            int sortingOrder)
        {
            var go = new GameObject($"MeshTile_{meshData.Name}");
            go.transform.SetParent(parent);
            
            // Position mesh tile to match board positioning
            // The mesh vertices were generated using world.Height (stored as GeneratedWithLevelHeight),
            // but Unity tiles use the actual level.Height
            // We need to compensate for this difference
            
            float meshGeneratedHeight = meshData.GeneratedWithLevelHeight;
            float actualLevelHeight = levelHeight;
            
            // The difference in coordinate systems:
            // Mesh vertices: tileY = (meshGeneratedHeight - position.Y - size.Y * 0.5f) * unitScale
            // Unity tiles:   tileY = (actualLevelHeight - position.Y - size.Y * 0.5f) * unitScale
            // Difference:    (actualLevelHeight - meshGeneratedHeight) * unitScale
            
            float heightDifference = actualLevelHeight - meshGeneratedHeight;
            float yOffset = heightDifference * world.UnitScale;
            
            go.transform.localPosition = new Vector3(0, yOffset, 0);
            go.transform.localScale = Vector3.one;
            
            var meshTile = go.AddComponent<MeshTile>();
            meshTile.Initialize(meshData, world, levelHeight);
            
            // Set sorting order on renderer to match tile z-order
            var renderer = go.GetComponent<MeshRenderer>();
            if (renderer != null)
            {
                // Use the same sorting calculation as individual tiles
                // From Tile.txt: spriteRenderer.sortingOrder = z * 2 + 1;
                renderer.sortingOrder = sortingOrder * 2;
                renderer.sortingLayerName = "Default";
            }

            return go;
        }
        
        public static T AddOrGetComponent<T>(this GameObject go) where T : Component
        {
            T component = go.GetComponent<T>();
            if (component == null)
                component = go.AddComponent<T>();
            return component;
        }
    }
}
