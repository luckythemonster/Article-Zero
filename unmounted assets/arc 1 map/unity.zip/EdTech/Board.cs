using System;

using UnityEngine;

namespace EdTech
{
    [Serializable]
    public partial class Board : MonoBehaviour
    {
        public float ParallaxX = 1;
        public float ParallaxY = 1;
        public Vector3 InitialPosition;
        public Vector3 ReferencePosition;
        public Vector3 Size;
        public Vector3 Delta;
        public BoardStamp Stamp;
        public string BoardName;
        public int Z;

        bool isInitialized = false;
        EdWorld world;
        EdBoard board;

        public void ResetInitialPositions()
        {
            InitialPosition = transform.position;
            ReferencePosition = Camera.main.transform.position;
        }

        public void BoardSpawned(EdWorld world, float levelHeight, EdBoard board, int z, BoardStamp stamp)
        {
            this.BoardName = board.Name;
            this.world = world;
            this.Stamp = stamp;
            this.board = board;
            this.Z = z;
            ResetInitialPositions();

            ParallaxX = board.ParallaxX;
            ParallaxY = board.ParallaxY;

            Size = EdExtensions.GetTilePosition(
                board.TileWidth, board.TileHeight, board.TileWidth, board.TileHeight,
                board.GapWidth, board.GapHeight, board.Width, board.Height) * world.UnitScale;

            isInitialized = true;
        }

        void Update()
        {
            if (!isInitialized) return;
            if (world.IsPaused) return;
            var camera = Camera.main;
            if (camera == null) return;
            var cameraPosition = camera.transform.position;
            Delta = cameraPosition - ReferencePosition;
            float deltaX = (1f - ParallaxX) * Delta.x;
            float deltaY = (1f - ParallaxY) * Delta.y;

            transform.position = new Vector3(
                InitialPosition.x + deltaX,
                InitialPosition.y + deltaY,
                InitialPosition.z
            );
        }
    }
}
